create
    definer = root@localhost procedure sp_select_by_id(IN id int)
BEGIN
	select * from customers where customerNumber = id;
END;

