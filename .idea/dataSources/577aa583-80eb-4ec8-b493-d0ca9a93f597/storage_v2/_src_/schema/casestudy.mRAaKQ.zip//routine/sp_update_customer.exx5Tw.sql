create
    definer = root@localhost procedure sp_update_customer(IN id int, IN sp_name varchar(50), IN sp_address varchar(120),
                                                          IN sp_email varchar(120), IN sp_phone varchar(20))
BEGIN
	UPDATE customers SET fullName = sp_name, address = sp_address, email = sp_email, phone = sp_phone WHERE customerNumber = id;
END;

