create
    definer = root@localhost procedure sp_insert_customer(IN customerId int, IN fname varchar(50),
                                                          IN sp_address varchar(120), IN sp_email varchar(120),
                                                          IN sp_phone varchar(20))
BEGIN
	INSERT INTO customers(customerNumber, fullName, address, email, phone) VALUES (customerId, fname, sp_address, sp_email, sp_phone);
END;

