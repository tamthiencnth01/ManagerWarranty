create
    definer = root@localhost procedure sp_delete_customer(IN id int)
BEGIN
	DELETE FROM customers where customerNumber = id;
END;

