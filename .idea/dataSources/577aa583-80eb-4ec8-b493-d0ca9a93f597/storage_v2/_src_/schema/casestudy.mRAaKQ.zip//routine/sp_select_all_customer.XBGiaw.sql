create
    definer = root@localhost procedure sp_select_all_customer()
BEGIN
	SELECT * from customers;
END;

